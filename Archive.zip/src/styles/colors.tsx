export const BLUE_RIBBON = '#0569F7';
export const ERROR = '#C50F0F';