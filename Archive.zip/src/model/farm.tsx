export interface Farm {
    displayname: string;
    name: string;
    phone: string;
    openHours: string;
    url: string;
}