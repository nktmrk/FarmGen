import * as React from 'react';
import './src/config/firebase';
import RootNavigation from './src/navigation';

export default function App() {
  return (
    <RootNavigation />
  );
}
